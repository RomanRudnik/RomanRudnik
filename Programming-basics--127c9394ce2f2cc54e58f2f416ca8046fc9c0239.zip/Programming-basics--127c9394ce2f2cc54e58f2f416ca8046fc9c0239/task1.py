my_text = "Hello, World!"
my_name = "\nDenis"
my_last_name = "Stohodiuk,"
my_year = 17

print(("Тип my_text:"), type(my_text), ("Тип my_name:"), type(
    my_name), ("Тип my_last_text:"), type(my_last_name),
    ("Тип my_year:"), type(my_year))
print(my_text, my_name, my_last_name, my_year)
